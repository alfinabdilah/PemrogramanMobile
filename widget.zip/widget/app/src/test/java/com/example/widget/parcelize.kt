package com.example.widget

annotation class parcelize
